﻿using System;
using System.Collections.Generic;
namespace QueuePractice
{
    class Program
    {
        static void Main()
        {
            Customer customer1 = new Customer()
            {
                ID = 101,
                Name = "Mohan",
                Salary = 500
            };

            Customer customer2 = new Customer()
            {
                ID = 102,
                Name = "Swaroop",
                Salary = 700
            };

            Customer customer3 = new Customer()
            {
                ID = 104,
                Name = "Venigalla",
                Salary = 5500
            };

            Customer customer4 = new Customer()
            {
                ID = 105,
                Name = "Allaginiv",
                Salary = 500
            };

            Customer customer5 = new Customer()
            {
                ID = 106,
                Name = "Nahom",
                Salary = 600
            };

            Console.WriteLine("----------------------------     Queue   -------------------------------");

            Queue<Customer> queueCustomers = new Queue<Customer>();

            queueCustomers.Enqueue(customer1);
            queueCustomers.Enqueue(customer2);
            queueCustomers.Enqueue(customer3);
            queueCustomers.Enqueue(customer4);
            queueCustomers.Enqueue(customer5);

            Customer c1 = queueCustomers.Dequeue();
            Console.WriteLine(c1.ID + " -  " + c1.Name);
            Console.WriteLine("Items left in the Queue = " + queueCustomers.Count);

            queueCustomers.Enqueue(customer1);

            foreach (Customer customer in queueCustomers)
            {
                Console.WriteLine(customer.ID + " -  " + customer.Name);
                Console.WriteLine("Items left in the Queue = " + queueCustomers.Count);
            }
            Console.WriteLine("-----------------------------------------------------------");

            // To retrieve an item that is present at the beginning of the 
            // queue, without removing it use Peek() method.
            Customer c = queueCustomers.Peek();
            Console.WriteLine(c.ID + " -  " + c.Name);
            Console.WriteLine("Items left in the Queue = " + queueCustomers.Count);
            Console.WriteLine("-----------------------------------------------------------");

            // To check if an item, exists in the queue, use Contains() method.
            if (queueCustomers.Contains(customer1))
            {
                Console.WriteLine("customer1 is in Queue");
            }
            else
            {
                Console.WriteLine("customer1 is not in Queue");
            }

            //Stack
            Console.WriteLine("------------------------------     Stack    -----------------------------");
            Stack<Customer> stackCustomers = new Stack<Customer>();
            // To add an item to the stack, use Push() method.
            // customer1 is inserted at the top of the stack
            stackCustomers.Push(customer1);
            // customer2 will be inserted on top of customer1 and now is on top of the stack
            stackCustomers.Push(customer2);
            // customer3 will be inserted on top of customer2 and now is on top of the stack
            stackCustomers.Push(customer3);
            stackCustomers.Push(customer4);
            stackCustomers.Push(customer5);

            // object is the one that is pushed onto the stack last, this object will be
            // first to be removed and returned from the stack by the Pop() method
            Customer stackc1 = stackCustomers.Pop();
            Console.WriteLine(stackc1.ID + " -  " + stackc1.Name);
            Console.WriteLine("Items left in the Stack = " + stackCustomers.Count);

            stackCustomers.Push(customer1);

            Customer stackc = stackCustomers.Peek();
            Console.WriteLine(stackc.ID + " -  " + stackc.Name);
            Console.WriteLine("Items left in the Stack = " + stackCustomers.Count);
            Console.WriteLine("-----------------------------------------------------------");

            // To check if an item, exists in the stack, use Contains() method.
            if (stackCustomers.Contains(customer1))
            {
                Console.WriteLine("customer1 is in stack");
            }
            else
            {
                Console.WriteLine("customer1 is not in stack");
            }


        }


    }

    public class Customer
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Salary { get; set; }

    }
}
