﻿using System;
using System.Collections.Generic;
using System.Linq;

public class DictionaryPractice
{
    public static void Main()
    {
        // Create Customer Objects
        Customer customer1 = new Customer()
        {
            ID = 101,
            Name = "Mohan",
            Salary = 500
        };

        Customer customer2 = new Customer()
        {
            ID = 102,
            Name = "Swaroop",
            Salary = 700
        };

        Customer customer3 = new Customer()
        {
            ID = 104,
            Name = "Venigalla",
            Salary = 5500
        };

        Customer customer4 = new Customer()
        {
            ID = 105,
            Name = "Allaginiv",
            Salary = 500
        };

        Customer customer5 = new Customer()
        {
            ID = 106,
            Name = "Nahom",
            Salary = 600
        };

        Dictionary<int, Customer> dictionaryCustomers = new Dictionary<int, Customer>
        {
            { customer1.ID, customer1 },
            { customer2.ID, customer2 },
            { customer3.ID, customer3 }
        };

        if (dictionaryCustomers.TryGetValue(999, out Customer customer999))
        {
            Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}", customer999.ID, customer999.Name, customer999.Salary);
        }
        else
        {
            Console.WriteLine("Customer with Key = 999 is not found in the dictionary");
            Console.WriteLine("-------------------------------------------------------------------");
        }

        Console.WriteLine("Total items in Dictionary = {0}", dictionaryCustomers.Count());
        Console.WriteLine("-------------------------------------------------------------------");

        // LINQ extension methods can be used with Dictionary. For example, to find the 
        // total employees whose salary is greater than 5000.
        Console.WriteLine("Items in dictionary where Salary is greater than 5000 = {0}",
            dictionaryCustomers.Count(x => x.Value.Salary > 5000));
        Console.WriteLine("-------------------------------------------------------------------");

        dictionaryCustomers.Remove(101);

           dictionaryCustomers.Clear();

        // Create an array of customers
        Customer[] arrayCustomers = new Customer[3];
        arrayCustomers[0] = customer1;
        arrayCustomers[1] = customer2;
        arrayCustomers[2] = customer3;
        
        Dictionary<int, Customer> dict = arrayCustomers.ToDictionary(customer => customer.ID, customer => customer);
        // OR        
        // Dictionary<int, Customr> dict = arrayCustomers.ToDictionary(customer => customer.ID);
        // OR use a foreach loop
        // Dictionary<int, Customer> dict = new Dictionary<int, Customer>();
        // foreach (Customer cust in arrayCustomers)
        // {
        //     dict.Add(cust.ID, cust);
        // }

        foreach (KeyValuePair<int, Customer> kvp in dict)
        {
            Console.WriteLine("Key = {0}", kvp.Key);
            Customer customr = kvp.Value;
            Console.WriteLine("ID = {0}, Name = {1}, Salary {2}", customr.ID, customr.Name, customr.Salary);
        }
        Console.WriteLine("-------------------------------------------------------------------");


        //List

        Console.WriteLine("------------------------------  List  -----------------------------");
        List<Customer> listCustomers = new List<Customer>(2);

        listCustomers.Add(customer1);
        listCustomers.Add(customer2);
                listCustomers.Add(customer3);

        Customer cust1 = listCustomers[0];
        Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}",
                 cust1.ID, cust1.Name, cust1.Salary);
        Console.WriteLine("------------------------------------------------");

       
        for (int i = 0; i < listCustomers.Count; i++)
        {
            Customer customer = listCustomers[i];
            Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}",
                     customer.ID, customer.Name, customer.Salary);
        }
        Console.WriteLine("------------------------------------------------");

        foreach (Customer C in listCustomers)
        {
            Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}", C.ID, C.Name, C.Salary);
        }
        Console.WriteLine("------------------------------------------------");

        // If you want to insert an item at a specific index location of the list, use Insert() method. 
        listCustomers.Insert(1, customer3);
        Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}",
               listCustomers[1].ID, listCustomers[1].Name, listCustomers[1].Salary);
        Console.WriteLine("------------------------------------------------");

        // To get the index of specific item in the list use Indexof() method
        Console.WriteLine("Index of Customer3 object in the List = " +
                listCustomers.IndexOf(customer3));
        Console.WriteLine("------------------------------------------------");

        if (listCustomers.Contains(customer2))
        {
            Console.WriteLine("Customer2 object exists in the list");
        }
        else
        {
            Console.WriteLine("Customer2 object does not exist in the list");
        }
        Console.WriteLine("------------------------------------------------------");

        // To check if an item exists in the list based on a condition, then use Exists() function
        if (listCustomers.Exists(x => x.Name.StartsWith("M")))
        {
            Console.WriteLine("List contains customer whose name starts with M");
        }
        else
        {
            Console.WriteLine("List does not contain a customer whose name starts with M");
        }
        Console.WriteLine("------------------------------------------------------");

        // Find() method searches for an element that matches the conditions defined by 

        Customer cust2 = listCustomers.Find(customer => customer.Salary > 5000);
        Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}", cust2.ID, cust2.Name, cust2.Salary);
        Console.WriteLine("------------------------------------------------------");

        List<Customer> listCustomers2 = new List<Customer>(2)
        {
            customer4,
            customer5
        };
        // AddRange() allows you to add another list of items, to the end of the list
        listCustomers.AddRange(listCustomers2);

        foreach (Customer customer in listCustomers)
        {
            Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}",
                customer.ID, customer.Name, customer.Salary);
        }
        Console.WriteLine("------------------------------------------------------");

        // GetRange() function returns a list of items from the list.



        List<Customer> corporateCustomers = listCustomers.GetRange(3, 2);
        foreach (Customer customer in corporateCustomers)
        {
            Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}",
                customer.ID, customer.Name, customer.Salary);
        }
        Console.WriteLine("------------------------------------------------------");

        // Remove() function removes only the first matching item from the list.
        listCustomers.Remove(customer1);

        // RemoveAt() function, removes the item at the specified index in the list.
        listCustomers.RemoveAt(0);


        foreach (Customer customer in listCustomers)
        {
            Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}",
                customer.ID, customer.Name, customer.Salary);
        }
        Console.WriteLine("------------------------------------------------------");

        listCustomers.RemoveRange(0, 2);

        foreach (Customer customer in listCustomers)
        {
            Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}",
                customer.ID, customer.Name, customer.Salary);
        }
        Console.WriteLine("------------------------------------------------------");

        Console.WriteLine("Customers before sorting");
        foreach (Customer customer in listCustomers)
        {
            Console.WriteLine(customer.Name + " - " + customer.Salary);
        }

        // Sort() method should sort customers by salary
        listCustomers.Sort();

        Console.WriteLine("Customers after sorting");
        foreach (Customer customer in listCustomers)
        {
            Console.WriteLine(customer.Name + " - " + customer.Salary);
        }

        //Queue

        Console.WriteLine("----------------------------     Queue   -------------------------------");

        Queue<Customer> queueCustomers = new Queue<Customer>();

        queueCustomers.Enqueue(customer1);
        queueCustomers.Enqueue(customer2);
        queueCustomers.Enqueue(customer3);
        queueCustomers.Enqueue(customer4);
        queueCustomers.Enqueue(customer5);

        Customer c1 = queueCustomers.Dequeue();
        Console.WriteLine(c1.ID + " -  " + c1.Name);
        Console.WriteLine("Items left in the Queue = " + queueCustomers.Count);

        queueCustomers.Enqueue(customer1);

        foreach (Customer customer in queueCustomers)
        {
            Console.WriteLine(customer.ID + " -  " + customer.Name);
            Console.WriteLine("Items left in the Queue = " + queueCustomers.Count);
        }
        Console.WriteLine("-----------------------------------------------------------");

        // To retrieve an item that is present at the beginning of the 
        // queue, without removing it use Peek() method.
        Customer c = queueCustomers.Peek();
        Console.WriteLine(c.ID + " -  " + c.Name);
        Console.WriteLine("Items left in the Queue = " + queueCustomers.Count);
        Console.WriteLine("-----------------------------------------------------------");

        // To check if an item, exists in the queue, use Contains() method.
        if (queueCustomers.Contains(customer1))
        {
            Console.WriteLine("customer1 is in Queue");
        }
        else
        {
            Console.WriteLine("customer1 is not in Queue");
        }

        //Stack
        Console.WriteLine("------------------------------     Stack    -----------------------------");
        Stack<Customer> stackCustomers = new Stack<Customer>();
        // To add an item to the stack, use Push() method.
        // customer1 is inserted at the top of the stack
        stackCustomers.Push(customer1);
        // customer2 will be inserted on top of customer1 and now is on top of the stack
        stackCustomers.Push(customer2);
        // customer3 will be inserted on top of customer2 and now is on top of the stack
        stackCustomers.Push(customer3);
        stackCustomers.Push(customer4);
        stackCustomers.Push(customer5);

        // object is the one that is pushed onto the stack last, this object will be
        // first to be removed and returned from the stack by the Pop() method
        Customer stackc1 = stackCustomers.Pop();
        Console.WriteLine(stackc1.ID + " -  " + stackc1.Name);
        Console.WriteLine("Items left in the Stack = " + stackCustomers.Count);

        stackCustomers.Push(customer1);

        Customer stackc = stackCustomers.Peek();
        Console.WriteLine(stackc.ID + " -  " + stackc.Name);
        Console.WriteLine("Items left in the Stack = " + stackCustomers.Count);
        Console.WriteLine("-----------------------------------------------------------");

        // To check if an item, exists in the stack, use Contains() method.
        if (stackCustomers.Contains(customer1))
        {
            Console.WriteLine("customer1 is in stack");
        }
        else
        {
            Console.WriteLine("customer1 is not in stack");
        }


    }


}

public class Customer : IComparable<Customer>
{
    public int ID { get; set; }
    public string Name { get; set; }
    public int Salary { get; set; }

    public int CompareTo(Customer obj)
    {
        //if (this.Salary > obj.Salary)
        //    return 1;
        //else if (this.Salary < obj.Salary)
        //    return -1;
        //else
        //    return 0;

        // OR, Alternatively you can also invoke CompareTo() method. 
        return this.Salary.CompareTo(obj.Salary);
    }
}