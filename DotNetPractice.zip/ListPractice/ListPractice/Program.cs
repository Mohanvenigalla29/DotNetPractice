﻿using System;
using System.Collections.Generic;

namespace ListPractice
{
    class Program
    {
        static void Main()
        {
            Customer customer1 = new Customer()
            {
                ID = 101,
                Name = "Mohan",
                Salary = 500
            };

            Customer customer2 = new Customer()
            {
                ID = 102,
                Name = "Swaroop",
                Salary = 700
            };

            Customer customer3 = new Customer()
            {
                ID = 104,
                Name = "Venigalla",
                Salary = 5500
            };

            Customer customer4 = new Customer()
            {
                ID = 105,
                Name = "Allaginiv",
                Salary = 500
            };

            Customer customer5 = new Customer()
            {
                ID = 106,
                Name = "Nahom",
                Salary = 600
            };

            List<Customer> listCustomers = new List<Customer>(2)
        {
            customer1,
            customer2,
            customer3
        };

            Customer cust1 = listCustomers[0];
            Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}",
                     cust1.ID, cust1.Name, cust1.Salary);
            Console.WriteLine("------------------------------------------------");


            for (int i = 0; i < listCustomers.Count; i++)
            {
                Customer customer = listCustomers[i];
                Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}",
                         customer.ID, customer.Name, customer.Salary);
            }
            Console.WriteLine("------------------------------------------------");

            foreach (Customer C in listCustomers)
            {
                Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}", C.ID, C.Name, C.Salary);
            }
            Console.WriteLine("------------------------------------------------");

            // If you want to insert an item at a specific index location of the list, use Insert() method. 
            listCustomers.Insert(1, customer3);
            Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}",
                   listCustomers[1].ID, listCustomers[1].Name, listCustomers[1].Salary);
            Console.WriteLine("------------------------------------------------");

            // To get the index of specific item in the list use Indexof() method
            Console.WriteLine("Index of Customer3 object in the List = " +
                    listCustomers.IndexOf(customer3));
            Console.WriteLine("------------------------------------------------");

            if (listCustomers.Contains(customer2))
            {
                Console.WriteLine("Customer2 object exists in the list");
            }
            else
            {
                Console.WriteLine("Customer2 object does not exist in the list");
            }
            Console.WriteLine("------------------------------------------------------");

            // To check if an item exists in the list based on a condition, then use Exists() function
            if (listCustomers.Exists(x => x.Name.StartsWith("M")))
            {
                Console.WriteLine("List contains customer whose name starts with M");
            }
            else
            {
                Console.WriteLine("List does not contain a customer whose name starts with M");
            }
            Console.WriteLine("------------------------------------------------------");

            // Find() method searches for an element that matches the conditions defined by 

            Customer cust2 = listCustomers.Find(customer => customer.Salary > 5000);
            Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}", cust2.ID, cust2.Name, cust2.Salary);
            Console.WriteLine("------------------------------------------------------");

            List<Customer> listCustomers2 = new List<Customer>(2)
        {
            customer4,
            customer5
        };
            // AddRange() allows you to add another list of items, to the end of the list
            listCustomers.AddRange(listCustomers2);

            foreach (Customer customer in listCustomers)
            {
                Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}",
                    customer.ID, customer.Name, customer.Salary);
            }
            Console.WriteLine("------------------------------------------------------");

            // GetRange() function returns a list of items from the list.



            List<Customer> corporateCustomers = listCustomers.GetRange(3, 2);
            foreach (Customer customer in corporateCustomers)
            {
                Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}",
                    customer.ID, customer.Name, customer.Salary);
            }
            Console.WriteLine("------------------------------------------------------");

            // Remove() function removes only the first matching item from the list.
            listCustomers.Remove(customer1);

            // RemoveAt() function, removes the item at the specified index in the list.
            listCustomers.RemoveAt(0);


            foreach (Customer customer in listCustomers)
            {
                Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}",
                    customer.ID, customer.Name, customer.Salary);
            }
            Console.WriteLine("------------------------------------------------------");

            listCustomers.RemoveRange(0, 2);

            foreach (Customer customer in listCustomers)
            {
                Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}",
                    customer.ID, customer.Name, customer.Salary);
            }
            Console.WriteLine("------------------------------------------------------");

            Console.WriteLine("Customers before sorting");
            foreach (Customer customer in listCustomers)
            {
                Console.WriteLine(customer.Name + " - " + customer.Salary);
            }

            // Sort() method should sort customers by salary
            listCustomers.Sort();

            Console.WriteLine("Customers after sorting");
            foreach (Customer customer in listCustomers)
            {
                Console.WriteLine(customer.Name + " - " + customer.Salary);
            }

        }
    }
}

public class Customer : IComparable<Customer>
{
    public int ID { get; set; }
    public string Name { get; set; }
    public int Salary { get; set; }

    public int CompareTo(Customer obj)
    {
        //if (this.Salary > obj.Salary)
        //    return 1;
        //else if (this.Salary < obj.Salary)
        //    return -1;
        //else
        //    return 0;

        // OR, Alternatively you can also invoke CompareTo() method. 
        return this.Salary.CompareTo(obj.Salary);
    }
}
